const axios = require("axios");
const Sentiment = require("sentiment");
const sentiment = new Sentiment();

async function fetchReddit(brand) {
    const url = `https://www.reddit.com/search.json?q=${brand}&limit=50`;

    const res = await axios.get(url, {
        headers: { "User-Agent": "brand-monitor" }
    });

    return res.data.data.children.map(p => p.data.title);
}

function analyze(posts) {
    let positive=0, negative=0, neutral=0;

    posts.forEach(text => {
        const score = sentiment.analyze(text).score;
        if(score>0) positive++;
        else if(score<0) negative++;
        else neutral++;
    });

    return { positive, negative, neutral };
}

module.exports = { fetchReddit, analyze };