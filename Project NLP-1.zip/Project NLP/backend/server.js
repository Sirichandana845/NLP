const express = require("express");
const http = require("http");
const cors = require("cors");
const mongoose = require("mongoose");
const { Server } = require("socket.io");

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
    cors: { origin: "*" }
});

// MongoDB connect
mongoose.connect("mongodb://127.0.0.1:27017/brandDB")
.then(() => console.log("MongoDB Connected"));

// Socket setup
io.on("connection", (socket) => {
    console.log("User connected");

    socket.on("disconnect", () => {
        console.log("User disconnected");
    });
});

// Routes
const brandRoutes = require("./routes/brandRoutes.js")(io);
app.use("/api", brandRoutes);

server.listen(5000, () => console.log("Server running"));