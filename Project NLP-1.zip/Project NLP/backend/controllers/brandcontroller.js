const Brand = require("../models/Brand");
const { fetchReddit, analyze } = require("../services/brandService");

module.exports = (io) => ({

    async getBrand(req, res) {
        try {
            const brand = req.params.name;

            const posts = await fetchReddit(brand);
            const sentiment = analyze(posts);

            const data = {
                name: brand,
                totalMentions: posts.length,
                ...sentiment
            };

            // Save to DB
            await Brand.create(data);

            // Send real-time update
            io.emit("update", data);

            res.json(data);

        } catch (err) {
            res.status(500).json({ error: "Something went wrong" });
        }
    }

});