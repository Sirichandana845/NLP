let lineChart, pieChart;

// 🔄 Load brand data
function loadBrand() {
    const brand = document.getElementById("brandInput").value || "nike";

    fetch(`http://localhost:5000/api/brand/${brand}`)
        .then(res => res.json())
        .then(data => {
            updateStats(data);
            updateCharts(data);
        })
        .catch(err => console.error("Error:", err));
}

// 📊 Update Stats
function updateStats(data) {
    document.getElementById("total").innerText = data.totalMentions;
    document.getElementById("positive").innerText = data.positive;
    document.getElementById("neutral").innerText = data.neutral;
    document.getElementById("negative").innerText = data.negative;
}

// 📈 Update Charts
function updateCharts(data) {

    // Destroy old charts (important)
    if (lineChart) lineChart.destroy();
    if (pieChart) pieChart.destroy();

    // 📈 Line Chart
    lineChart = new Chart(document.getElementById("lineChart"), {
        type: "line",
        data: {
            labels: data.timeline?.labels || [],
            datasets: [{
                label: "Mentions",
                data: data.timeline?.data || [],
                borderColor: "#2196F3",
                fill: false,
                tension: 0.3
            }]
        }
    });

    // 🥧 Pie Chart
    pieChart = new Chart(document.getElementById("pieChart"), {
        type: "doughnut",
        data: {
            labels: ["Positive", "Neutral", "Negative"],
            datasets: [{
                data: [
                    data.positive || 0,
                    data.neutral || 0,
                    data.negative || 0
                ],
                backgroundColor: ["#4CAF50", "#2196F3", "#f44336"]
            }]
        }
    });
}

// 🚀 Auto load default brand on page load
window.onload = () => {
    loadBrand();
};