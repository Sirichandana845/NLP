const express = require("express");

module.exports = (io) => {
    const router = express.Router();

    const controller = require("../controllers/brandcontroller")(io);

    router.get("/brand/:name", controller.getBrand);

    return router;
};