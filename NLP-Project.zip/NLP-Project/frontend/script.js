const socket = io("http://localhost:5000");

let currentDataA = null;
let currentDataB = null;

// The neon dark colors mapped from CSS
const CHART_COLORS = {
    brandA: '#06b6d4', // Cyan
    brandA_bg: 'rgba(6, 182, 212, 0.15)',
    brandB: '#ec4899', // Pink
    brandB_bg: 'rgba(236, 72, 153, 0.15)',
    grid: 'rgba(255, 255, 255, 0.05)',
    text: '#8b95a5',
    pos: '#10b981',
    neu: '#8b95a5',
    neg: '#f43f5e'
};

socket.on("update", (data) => {
    console.log("Real-time update:", data.name);
    const brandA = document.getElementById("brandInputA").value || "Nike";
    const brandB = document.getElementById("brandInputB").value || "Adidas";

    let changed = false;
    if (data.name.toLowerCase() === brandA.toLowerCase()) {
        currentDataA = data;
        updateDonutChart("donutChartA", data);
        updateWordCloud(data, 'A');
        changed = true;
    } 
    if (data.name.toLowerCase() === brandB.toLowerCase()) {
        currentDataB = data;
        updateDonutChart("donutChartB", data);
        changed = true;
    }
    
    if (changed && currentDataA && currentDataB) {
        updateComparisonChart(currentDataA, currentDataB);
        renderLiveFeed(currentDataA.recentPosts, currentDataB.recentPosts);
    }
});

async function loadComparison() {
    const brandA = document.getElementById("brandInputA").value || "Nike";
    const brandB = document.getElementById("brandInputB").value || "Adidas";

    document.getElementById("live-feed-container").innerHTML = "<p style='color: #6a718c; text-align:center; margin-top:20px; grid-column:span 2;'>Fetching global NLP insights...</p>";

    try {
        const [resA, resB] = await Promise.all([
            fetch(`http://localhost:5000/api/brand/${brandA}`),
            fetch(`http://localhost:5000/api/brand/${brandB}`)
        ]);

        if (!resA.ok || !resB.ok) throw new Error("Backend is offline or threw an internal error.");

        const dataA = await resA.json();
        const dataB = await resB.json();
        
        currentDataA = dataA;
        currentDataB = dataB;

        updateDonutChart("donutChartA", dataA);
        updateDonutChart("donutChartB", dataB);
        
        updateWordCloud(dataA, 'A'); 
        updateComparisonChart(dataA, dataB);
        renderLiveFeed(dataA.recentPosts, dataB.recentPosts);

    } catch (err) {
        console.error("Fetch Error:", err);
        document.getElementById("live-feed-container").innerHTML = `<p style='color: #f43f5e; text-align:left; margin-top:20px; grid-column:span 2; white-space: pre-wrap; font-family: monospace; font-size: 10px;'>Error: ${err.toString()}\n${err.stack}</p>`;
    }
}

function renderLiveFeed(postsA = [], postsB = []) {
    const container = document.getElementById("live-feed-container");
    container.innerHTML = ""; // Clear
    
    // Intertwine the posts for visual aesthetic
    const maxSize = Math.max(postsA.length, postsB.length);
    for(let i = 0; i < maxSize; i++) {
        if(postsA[i]) container.appendChild(createPostCard(postsA[i], 'A'));
        if(postsB[i]) container.appendChild(createPostCard(postsB[i], 'B'));
    }

    if(postsA.length === 0 && postsB.length === 0) {
        container.innerHTML = "<p style='color: #6a718c; grid-column:span 2; text-align:center;'>No live mentions found.</p>";
    }
}

function createPostCard(post, brandSuffix) {
    const div = document.createElement("div");
    const isPos = post.sentiment === 'POSITIVE';
    const isNeg = post.sentiment === 'NEGATIVE';
    div.className = `post-card ${isPos ? 'positive' : isNeg ? 'negative' : ''}`;

    const iconClass = post.source === 'Reddit' ? 'reddit-icon fa-brands fa-reddit' : 'hn-icon fa-brands fa-y-combinator';
    const badgeClass = isPos ? 'badge-pos' : isNeg ? 'badge-neg' : '';
    
    // Convert timestamp
    const rtf = new Intl.RelativeTimeFormat('en', { numeric: 'auto' });
    const diffInSeconds = Math.floor(Date.now() / 1000) - post.created_utc;
    const timeStr = diffInSeconds < 3600 ? `${Math.floor(diffInSeconds/60)}m ago` : `${Math.floor(diffInSeconds/3600)}h ago`;

    div.innerHTML = `
        <div class="post-header">
            <div style="display:flex; gap:10px; align-items:center;">
                <div class="source-icon ${iconClass}"></div>
                <div class="post-user">${post.user || '@anon'}</div>
            </div>
            <div class="post-time">${timeStr}</div>
        </div>
        <div class="post-content">${post.title}</div>
        <div class="sentiment-badge ${badgeClass}">[${post.sentiment}]</div>
    `;
    return div;
}

function updateDonutChart(canvasId, data) {
    const existingChart = Chart.getChart(canvasId);
    if (existingChart) existingChart.destroy();
    
    const ctx = document.getElementById(canvasId).getContext("2d");
    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Positive', 'Neutral', 'Negative'],
            datasets: [{
                data: [data.positive, data.neutral, data.negative],
                backgroundColor: [CHART_COLORS.pos, CHART_COLORS.neu, CHART_COLORS.neg],
                borderWidth: 0,
                hoverOffset: 4
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            }
        }
    });
}

function updateWordCloud(data, suffix) {
    const canvas = document.getElementById(`wordcloud-canvas-${suffix}`);
    if (!data.words || data.words.length === 0) return;

    const list = data.words.map(item => [item.word, item.count * 12 + 10]);
    WordCloud(canvas, { 
        list: list, 
        gridSize: 12,
        weightFactor: 1, 
        fontFamily: '"Outfit", sans-serif', 
        color: function() {
            // Randomize between brand colors or whites
            const colors = [CHART_COLORS.brandA, CHART_COLORS.brandB, '#e2e8f0', '#8b95a5', CHART_COLORS.pos];
            return colors[Math.floor(Math.random() * colors.length)];
        }, 
        backgroundColor: 'transparent',
        rotateRatio: 0.1,
    });
}

function updateComparisonChart(dataA, dataB) {
    const existingChart = Chart.getChart("lineChart");
    if (existingChart) existingChart.destroy();

    const labelsSet = new Set([...(dataA.timeline?.labels || []), ...(dataB.timeline?.labels || [])]);
    const labels = Array.from(labelsSet).sort();

    const mappedDataA = labels.map(l => { const idx = dataA.timeline?.labels.indexOf(l); return idx > -1 ? dataA.timeline.data[idx] : 0; });
    const mappedDataB = labels.map(l => { const idx = dataB.timeline?.labels.indexOf(l); return idx > -1 ? dataB.timeline.data[idx] : 0; });

    new Chart(document.getElementById("lineChart"), {
        type: "line",
        data: {
            labels: labels,
            datasets: [
                {
                    label: dataA.name,
                    data: mappedDataA,
                    borderColor: CHART_COLORS.brandA,
                    backgroundColor: CHART_COLORS.brandA_bg,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0
                },
                {
                    label: dataB.name,
                    data: mappedDataB,
                    borderColor: CHART_COLORS.brandB,
                    backgroundColor: CHART_COLORS.brandB_bg,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: { grid: { color: CHART_COLORS.grid }, ticks: { color: CHART_COLORS.text, maxTicksLimit: 8 } },
                y: { grid: { color: CHART_COLORS.grid }, ticks: { color: CHART_COLORS.text } }
            }
        }
    });
}

// Clock
setInterval(() => {
    const d = new Date();
    document.getElementById("clock").innerText = d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
}, 1000);

// SPA View Routing
function switchTab(tabId, element = null) {
    if (tabId === 'coming-soon') {
        alert("🔒 This module is currently locked in the prototype phase.");
        return;
    }

    // Un-active all links
    document.querySelectorAll('.nav-links li').forEach(li => li.classList.remove('active'));
    
    // Find the one that matches or passed element
    if (element) {
        element.classList.add('active');
    }

    // Hide all main views
    document.querySelectorAll('.app-view').forEach(view => view.classList.add('hidden'));

    const grid = document.getElementById('dashboard-view');
    grid.className = 'dashboard-grid app-view'; // reset to standard View

    const dashboardSubViews = ['dashboard', 'realtime', 'sentiment', 'competitor'];
    
    if (dashboardSubViews.includes(tabId)) {
        grid.classList.remove('hidden');
        if (tabId !== 'dashboard') {
            grid.classList.add(`view-${tabId}`);
        }
    } else {
        const targetView = document.getElementById(`${tabId}-view`);
        if (targetView) targetView.classList.remove('hidden');
        
        if (tabId === 'crisis') {
             renderCrisisFeed();
        }
    }

    // Chart.js requires manual resize triggers when container dimensions instantly change
    setTimeout(() => {
        const c1 = Chart.getChart("lineChart"); if(c1) c1.resize();
        const c2 = Chart.getChart("donutChartA"); if(c2) c2.resize();
        const c3 = Chart.getChart("donutChartB"); if(c3) c3.resize();
    }, 50);
}

function renderCrisisFeed() {
    const container = document.getElementById("crisis-feed-container");
    if (!container) return;
    container.innerHTML = "";
    
    const allPosts = [];
    if (currentDataA && currentDataA.recentPosts) allPosts.push(...currentDataA.recentPosts.map(p => ({...p, brandSuffix: 'A'})));
    if (currentDataB && currentDataB.recentPosts) allPosts.push(...currentDataB.recentPosts.map(p => ({...p, brandSuffix: 'B'})));
    
    // Filter for NEGATIVE sentiment to represent a "Crisis" state
    const criticalPosts = allPosts.filter(p => p.sentiment === 'NEGATIVE');
    
    // Sort by most recent
    criticalPosts.sort((a,b) => b.created_utc - a.created_utc);
    
    if (criticalPosts.length === 0) {
        container.innerHTML = "<p style='color: #10b981; text-align:center; margin-top:20px;'><br><br><i class='fa-solid fa-check-circle' style='font-size:24px; margin-bottom:10px;'></i><br>Zero critical mentions detected right now.<br>Brand health is stable.</p>";
        return;
    }
    
    criticalPosts.forEach(post => {
        container.appendChild(createPostCard(post, post.brandSuffix));
    });
}
function exportCSV() {
    const allPosts = [];
    if (currentDataA && currentDataA.recentPosts) {
        currentDataA.recentPosts.forEach(p => allPosts.push({ Brand: currentDataA.name, Title: `"${p.title.replace(/"/g, '""')}"`, Sentiment: p.sentiment, Source: p.source, Timestamp: p.created_utc }));
    }
    if (currentDataB && currentDataB.recentPosts) {
        currentDataB.recentPosts.forEach(p => allPosts.push({ Brand: currentDataB.name, Title: `"${p.title.replace(/"/g, '""')}"`, Sentiment: p.sentiment, Source: p.source, Timestamp: p.created_utc }));
    }

    if (allPosts.length === 0) {
        return alert("No data available to export.");
    }

    const headers = Object.keys(allPosts[0]).join(",");
    const rows = allPosts.map(p => Object.values(p).join(",")).join("\n");
    const csvContent = headers + "\n" + rows;

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "BrandVision_Mentions.csv";
    link.click();
}

function exportPDF() {
    // Generate snapshot of the Analytics Column
    const element = document.querySelector(".analytics-column");
    if (!element) return alert("Nothing to export yet.");
    
    // Configure html2pdf
    const opt = {
        margin:       0.5,
        filename:     'BrandVision_Executive_Summary.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, backgroundColor: "#131722" },
        jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    
    html2pdf().set(opt).from(element).save();
}

window.onload = loadComparison;